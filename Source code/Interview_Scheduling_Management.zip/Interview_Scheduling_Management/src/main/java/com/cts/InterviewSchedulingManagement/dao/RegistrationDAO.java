package com.cts.InterviewSchedulingManagement.dao;

import com.cts.InterviewSchedulingManagement.bean.Candidate;

public interface RegistrationDAO {

	public String registerCandidate(Candidate candidate);
	
}
